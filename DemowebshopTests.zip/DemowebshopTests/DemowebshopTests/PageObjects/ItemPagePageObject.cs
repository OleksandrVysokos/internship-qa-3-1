﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace DemowebshopTests.PageObjects
{
    class ItemPagePageObject
    {
        private IWebDriver _webdriver;
        private readonly By _addToCartFromItemPage = By.CssSelector("#add-to-cart-button-31");
        private readonly By _addToCompareListFromItemPageButton = By.CssSelector(".compare-products");
        private readonly By _enterRecipientsName = By.CssSelector("#giftcard_4_RecipientName");
        private readonly By _enterYourName = By.XPath("//input[@class='sender-name']");
        private readonly By _enterMessageGiftCard = By.XPath("//textarea[@class='message']");
        private readonly By _addtoCartGiftCard = By.CssSelector("#add-to-cart-button-4");
        private const string _validSenderName = "User Userok";
        private readonly By _addToCartBook = By.CssSelector("#add-to-cart-button-13");
        private readonly By _addToCartJawerly = By.CssSelector("#add-to-cart-button-14");


        public ItemPagePageObject(IWebDriver webDriver)
        {
            _webdriver = webDriver;
        }
        public ItemPagePageObject AddToCartFromItemPage()
        {
            WaitUntil.WaitElement(_webdriver, _addToCartFromItemPage);
            _webdriver.FindElement(_addToCartFromItemPage).Click();
            return new ItemPagePageObject(_webdriver);

        }
        public ItemPagePageObject AddToCompareList()
        {
            
            _webdriver.FindElement(_addToCompareListFromItemPageButton).Click();
            return new ItemPagePageObject(_webdriver);

        }
        public ItemPagePageObject EnterDataForGiftCard()
        {
            WaitUntil.WaitElement(_webdriver, _enterRecipientsName);
            _webdriver.FindElement(_enterRecipientsName).SendKeys(RandomDataGenerator.GenerateRandomString(5));
             WaitUntil.WaitElement(_webdriver, _enterYourName);
             //_webdriver.FindElement(_enterYourName).Click();
            _webdriver.FindElement(_enterYourName).SendKeys(_validSenderName);
            WaitUntil.WaitElement(_webdriver, _enterMessageGiftCard);
            _webdriver.FindElement(_enterMessageGiftCard).SendKeys(RandomDataGenerator.GenerateRandomString(35));
            _webdriver.FindElement(_addtoCartGiftCard).Click();
            return new ItemPagePageObject(_webdriver);
        }
        public ItemPagePageObject AddToCartChosenBook()
        {
            WaitUntil.WaitElement(_webdriver, _addToCartBook);
            _webdriver.FindElement(_addToCartBook).Click();
            return new ItemPagePageObject(_webdriver);
        }
        public ItemPagePageObject AddToCartChosenNotebook()
        {
            WaitUntil.WaitElement(_webdriver, _addToCartFromItemPage);
            _webdriver.FindElement(_addToCartFromItemPage).Click();
            return new ItemPagePageObject(_webdriver);
        }
        public ItemPagePageObject AddToCartChosenJawerly()
        {
            WaitUntil.WaitElement(_webdriver, _addToCartJawerly);
            _webdriver.FindElement(_addToCartJawerly).Click();
            return new ItemPagePageObject(_webdriver);
        }
    }
}

