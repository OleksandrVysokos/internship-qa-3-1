﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
    class FooterMenuPageObject
    {
        private IWebDriver _webdriver;
        private readonly By _facebookButton = By.XPath("//a[@href='http://www.facebook.com/nopCommerce']");
        private readonly By _twitterButton = By.XPath("//a[@href='https://twitter.com/nopCommerce']");
        private readonly By _youtubeButton = By.XPath("//a[@href='http://www.youtube.com/user/nopCommerce']");
        private readonly By _rssButton = By.XPath("//a[@href='/news/rss/1']");
        private readonly By _googlePlusButton = By.XPath("//a[@href='https://plus.google.com/+nopcommerce']");

        public FooterMenuPageObject(IWebDriver webdriver)
        {
            _webdriver = webdriver;
        }
        public FooterMenuPageObject OpenFacebookPage()
        {
            WaitUntil.WaitElement(_webdriver, _facebookButton);
            _webdriver.FindElement(_facebookButton).Click();
            return new FooterMenuPageObject(_webdriver);
        }
        public FooterMenuPageObject OpenTwitterPage()
        {
            WaitUntil.WaitElement(_webdriver, _twitterButton);
            _webdriver.FindElement(_twitterButton).Click();
            return new FooterMenuPageObject(_webdriver);
        }
        public FooterMenuPageObject OpenRssPage()
        {
            WaitUntil.WaitElement(_webdriver, _rssButton);
            _webdriver.FindElement(_rssButton).Click();
            return new FooterMenuPageObject(_webdriver);
        }
        public FooterMenuPageObject OpenYoutubePage()
        {
            WaitUntil.WaitElement(_webdriver, _youtubeButton);
            _webdriver.FindElement(_youtubeButton).Click();
            return new FooterMenuPageObject(_webdriver);
        }
        public FooterMenuPageObject OpenGooglePlusPage()
        {
            WaitUntil.WaitElement(_webdriver, _googlePlusButton);
            _webdriver.FindElement(_googlePlusButton).Click();
            return new FooterMenuPageObject(_webdriver);
        }
    }
}
