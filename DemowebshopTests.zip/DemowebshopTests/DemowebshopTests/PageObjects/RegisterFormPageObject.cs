﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
   
    class RegisterFormPageObject
    {
      private IWebDriver _webdriver;
        private readonly By _firstName = By.CssSelector("#FirstName");
        private readonly By _lastName = By.CssSelector("#LastName");
        private readonly By _emailField = By.CssSelector("#Email");
        private readonly By _passwordField = By.CssSelector("#Password");
        private readonly By _confirmPasswordField = By.CssSelector("#ConfirmPassword");
        private readonly By _registerInputButton = By.CssSelector("#register-button");
        private const string _validFirstName = "User";
        private const string _validLastName = "Userok";
        private const string _validEmail = "ukraine993377@gmail.com";
        private const string _validPassword = "user11";
        private const string _confirmValidPassword = "user11";


        public RegisterFormPageObject(IWebDriver webdriver)
        {
            _webdriver = webdriver;
        }
        public MainMenuPageObject RegistrationValidData()
        {
            _webdriver.FindElement(_firstName).SendKeys(_validFirstName);
            _webdriver.FindElement(_lastName).SendKeys(_validLastName);
            _webdriver.FindElement(_emailField).SendKeys(_validEmail);
            _webdriver.FindElement(_passwordField).SendKeys(_validPassword);
            _webdriver.FindElement(_confirmPasswordField).SendKeys(_confirmValidPassword);
            _webdriver.FindElement(_registerInputButton).Click();
            return new MainMenuPageObject(_webdriver);
        }
    }
}
