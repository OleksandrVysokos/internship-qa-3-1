﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace DemowebshopTests.PageObjects
{
    class AuthorizationFormPageObject
    {
        private IWebDriver _webdriver;
        private readonly By _logInInputButton = By.CssSelector(".ico-login");
        private readonly By _emailAuthorizationField = By.CssSelector("#Email");
        private const string _validEmail = "ukraine993377@gmail.com";
        private readonly By _passwordAuthorizationField = By.CssSelector("#Password");
        private const string _validPassword = "user11";
        private readonly By _logInButton = By.XPath("//input[@class='button-1 login-button']");
        public AuthorizationFormPageObject(IWebDriver webDriver)
        {
            _webdriver = webDriver;
        }
        public MainMenuPageObject AuthorizationUsingValidData()
        {
            _webdriver.FindElement(_logInInputButton).Click();
            _webdriver.FindElement(_emailAuthorizationField).SendKeys(_validEmail);
            _webdriver.FindElement(_passwordAuthorizationField).SendKeys(_validPassword);
            _webdriver.FindElement(_logInButton).Click();
            return new MainMenuPageObject(_webdriver);


        }
    }
}
