﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
    class ContactUsFormPagePageObject
    {
        private IWebDriver _webdriver;
        private readonly By _yourNameField = By.CssSelector("#FullName");
        private readonly By _yourEmailField = By.CssSelector("#Email");
        private readonly By _messageField = By.CssSelector("#Enquiry");
        private readonly By _submitButton = By.XPath("//input[@name='send-email']");
        private const string _validEmail = "ukraine993377@gmail.com";
        private const string _validFullName = "User Userok";

        public ContactUsFormPagePageObject(IWebDriver webdriver)
        {
            _webdriver = webdriver;
        }

        public ContactUsFormPagePageObject EnterDataToNameAndEmaiFields()
        {
            _webdriver.FindElement(_yourNameField).SendKeys(_validFullName);
            _webdriver.FindElement(_yourEmailField).SendKeys(_validEmail);
            return new ContactUsFormPagePageObject(_webdriver);
        }
        public ContactUsFormPagePageObject EnterRandomMessage()
        {
            WaitUntil.WaitElement(_webdriver, _messageField);
            _webdriver.FindElement(_messageField).SendKeys(RandomDataGenerator.GenerateRandomString(20));
            return new ContactUsFormPagePageObject(_webdriver);
        }
        public ContactUsFormPagePageObject SendMessageInContactUsForm()
        {
            WaitUntil.WaitElement(_webdriver, _submitButton);
            _webdriver.FindElement(_submitButton).Click();
            return new ContactUsFormPagePageObject(_webdriver);

        }
    }
}
