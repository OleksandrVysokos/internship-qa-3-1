﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
    class CatalogOfProductsPageObject
    {
        private IWebDriver _webdriver;
        private readonly By _SortByNameZtoA = By.XPath("//option[@value='http://demowebshop.tricentis.com/desktops?orderby=6']");
        private readonly By _selectFirstComputerFromCatalog = By.XPath("//a[@href='/simple-computer']");
        private readonly By _selectGiftCardTask5 = By.XPath("//a[@href='/100-physical-gift-card']");
        private readonly By _selectBookTask5 = By.XPath("//a[@href='/computing-and-internet']");
        private readonly By _selectNotebookTask5 = By.XPath("//img[@src='http://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_125.png']");
        private readonly By _selectJawerlyTask5 = By.XPath("//img[@src='http://demowebshop.tricentis.com/content/images/thumbs/0000029_black-white-diamond-heart_125.jpg']");

        public CatalogOfProductsPageObject(IWebDriver webdriver)
        {
            _webdriver = webdriver;
        }

        public CatalogOfProductsPageObject SortDesktopsByNameZtoA()
        {
            WaitUntil.WaitElement(_webdriver, _SortByNameZtoA);
            _webdriver.FindElement(_SortByNameZtoA).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
        public CatalogOfProductsPageObject SelectFirstComputer()
        {
            WaitUntil.WaitElement(_webdriver, _selectFirstComputerFromCatalog);
            _webdriver.FindElement(_selectFirstComputerFromCatalog).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
        public CatalogOfProductsPageObject Select100DollarsGiftCard()
        {
            WaitUntil.WaitElement(_webdriver, _selectGiftCardTask5);
            _webdriver.FindElement(_selectGiftCardTask5).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
        public CatalogOfProductsPageObject SelectAnyBook()
        {
            WaitUntil.WaitElement(_webdriver, _selectBookTask5);
            _webdriver.FindElement(_selectBookTask5).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
        public CatalogOfProductsPageObject SelectNotebook()
        {
            WaitUntil.WaitElement(_webdriver, _selectNotebookTask5);
            _webdriver.FindElement(_selectNotebookTask5).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
        public CatalogOfProductsPageObject SelectJawerly()
        {
            WaitUntil.WaitElement(_webdriver, _selectJawerlyTask5);
            _webdriver.FindElement(_selectJawerlyTask5).Click();
            return new CatalogOfProductsPageObject(_webdriver);
        }
    }
}
