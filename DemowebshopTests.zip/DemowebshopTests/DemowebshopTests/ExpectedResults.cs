﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests
{
    

    class ExpectedResults
    {
        private IWebDriver _webdriver;
        private const string _expectedAfterUnsuccessfullRegisterWhenEmailAlreadyRegistred = "The specified email already exists";
        private const string _expectedLogin = "ukraine993377@gmail.com";
        private const string _expectedRegistrationResult = "Your registration completed";
        private const string _expectedPriceInCompareList = "Price 800.00";
        private const string _expectedResultAfterSendingMessage = "Your enquiry has been successfully sent to the store owner.";
        private const string _expectedResultAfterCheckout = "Your order has been successfully processed!";
    }
    pu
}
